#!/bin/bash

echo "Original Code: " `date`
./md0 > md-v0.out
echo "Version 1 Code: " `date`
./md1 > md-v1.out
echo "Version 2 Code: " `date`
./md2 < md.inp > md-v2.out
echo "Version 3 Code: " `date`
./md3 < md.in > md-v3.out
echo "Version 4 Code: " `date`
./md4 < md.in > md-v4.out
echo "Version 5 Code: " `date`
./md5 < md.in > md-v5.out
echo "Done Running MD" `date`
